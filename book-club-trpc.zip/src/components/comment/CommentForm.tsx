import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Button, Group, Text } from "@mantine/core";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { onPromise } from "../../utils/promise-wrapper";
import { trpc } from "../../utils/trpc";
import DynamicRichText from "../dynamicRichText";

function CommentsForm({
  parentId,
  setReplying,
}: {
  parentId?: string;
  setReplying?: (active: boolean) => void;
}) {
  const router = useRouter();
  const [buddyReadId, setBuddyReadId] = useState("");
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");
  useEffect(() => {
    if (router.isReady) {
      setBuddyReadId(router.query.buddyReadId as string);
    }
  }, [router.isReady, router.query.buddyReadId]);

  const commentSchema = z.object({
    comment: z.string(),
  });
  type commentType = z.infer<typeof commentSchema>;

  const { handleSubmit, setValue, reset } = useForm<commentType>({
    resolver: zodResolver(commentSchema),
  });

  function onSubmit(values: commentType) {
    if (values.comment.replace(/(<([^>]+)>)/gi, "").length < 1) {
      setError("Comment cannot be empty");
      return;
    }
    const payload = { body: values.comment, buddyReadId, parentId };
    console.log(payload);
    mutate(payload);
  }
  const utils = trpc.useContext();
  const { mutate, isLoading } = trpc.useMutation(["comments.add-comment"], {
    onSuccess: async () => {
      if (parentId ) {
        console.log("shiourld run")
        if(setReplying) setReplying(false);
        
      }
      reset({
        comment: "",
      });
      setComment("");
      await utils.invalidateQueries(["comments.all-comments", { buddyReadId }]);
    },
  });
  return (
    <>
      <Box mb={"md"} mt={parentId ? "xs" : "md"}>
        <form
          className=" text-lg text-gray-600 "
          onSubmit={onPromise(
            handleSubmit(onSubmit, (e) => {
              console.log(e);
            })
          )}
        >
          <DynamicRichText
            controls={[
              [
                "bold",
                "italic",
                "underline",
                "h3",
                "blockquote",
                "alignLeft",
                "alignCenter",
                "alignRight",
                "video",
              ],
            ]}
            placeholder="Write a comment..."
            value={comment}
            mr="xs"
            onChange={(e) => {
              setComment(e);
              setError("");
              setValue("comment", e);
            }}
          />
          <Group position="apart" align={"center"} mt="md"  >
            <Text color={"red"} size="xs">
              {error ? "Can't post empty messages" : ""}
            </Text>
            <Button loading={isLoading} size="xs" type="submit" mr="xs" >
              {parentId ? "Post Reply" : "Post"}
            </Button>
          </Group>
        </form>
      </Box>
    </>
  );
}
export default CommentsForm;
