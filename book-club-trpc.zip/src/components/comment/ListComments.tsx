import {
  Avatar,
  Box,
  Button,
  Group,
  Paper,
  Text,
  TypographyStylesProvider,
} from "@mantine/core";
import { useState } from "react";
import { CommentWithChildren } from "../../utils/trpc";
import CommentForm from "./CommentForm";
function getReplyCountText(count: number) {
  if (count === 0) {
    return "No replies";
  }

  if (count === 1) {
    return "1 reply";
  }

  return `${count} replies`;
}
function CommentActions({
  commentId,
  replyCount,
}: {
  commentId: string;
  replyCount: number;
}) {
  const [replying, setReplying] = useState(false);

  return (
    <>
      <Group position="apart" mt="md">
        <Text>{getReplyCountText(replyCount)}</Text>
        <Button size="xs" mr="xs" variant="outline" onClick={() => setReplying(!replying)}>Reply</Button>
      </Group>

      {replying && (
        <CommentForm parentId={commentId} setReplying={setReplying} />
      )}
    </>
  );
}

function Comment({ comment }: { comment: CommentWithChildren }) {
  return (
    <>
      <Paper withBorder radius="md" mb={comment.children?"xs":"md"}  sx={()=>({
        paddingTop: "1rem",
        paddingBottom: "0.1rem",
        paddingLeft: "1rem",
        marginRight: -1
      })}>
        <Box
          sx={() => ({
            display: "flex",
          })}
        >
          <Avatar />
          <Box
            pl={"xs"}
            sx={() => ({
              display: "flex",
              flexDirection: "column",
            })}
          >
            <Group>
              <Text>{comment.user.username}</Text>
              <Text>{comment.createdAt.toISOString()}</Text>
            </Group>
            <TypographyStylesProvider>
              <Text>
                <div
                  className=" w-full break-words"
                  dangerouslySetInnerHTML={{ __html: comment.message }}
                />
              </Text>
            </TypographyStylesProvider>
          </Box>
        </Box>
        <CommentActions
          commentId={comment.id}
          replyCount={comment.children.length}
        />

        {comment.children && comment.children.length > 0 && (
          <ListComments comments={comment.children} />
        )}
      </Paper>
    </>
  );
}

function ListComments({ comments }: { comments: Array<CommentWithChildren> }) {
  return (
    <Box>
      {comments.map((comment) => {
        return <Comment key={comment.id} comment={comment} />;
      })}
    </Box>
  );
}
export default ListComments;
