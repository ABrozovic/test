import Image from "next/image";
import { useContext, useEffect, useState } from "react";
import {
  Accordion,
  AccordionItem,
  AccordionItemButton,
  AccordionItemHeading,
  AccordionItemPanel,
} from "react-accessible-accordion";
import { FaAngleLeft, FaAngleRight, FaChevronRight } from "react-icons/fa";
import CreateBookPage from "./book/upload";
import { BookContext } from "./store";
function Test() {
  const [bookArray, setBookArray] = useState<Item[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchText, setSearchText] = useState("");
  const useBook = useContext(BookContext);
  const url =
    "https://www.googleapis.com/books/v1/volumes?q=flowers+inauthor:keyes&key=AIzaSyDW5QZg-yWOm2ptT3o4aoqD-ozGBa9011c";

  useEffect(() => {
    api<BookSearch>(url)
      .then((data) => {
        if (data && data.items && data.items.length > 1) {
          setBookArray(data.items);
          //   const book = (data.items[0] as Item).volumeInfo;
          //   useBook.setBook({
          //     id: 0,
          //     title: book.title,
          //     description: book.description ? book.description : "",
          //     author: book.authors,
          //     smallThumbnail: book.imageLinks.smallThumbnail,
          //     thumbnail: book.imageLinks.thumbnail,
          //   });
          console.log(data.items);
        }
        // console.log(useBook.book);
      })
      .catch((error) => {
        /* show error message */
        console.log(error);
      });
  }, []);
  const searchBook = async (bookName: string) => {
    await api<BookSearch>(
      `https://www.googleapis.com/books/v1/volumes?q=${bookName}&key=AIzaSyDW5QZg-yWOm2ptT3o4aoqD-ozGBa9011c`
    ).then((data) => {
      if (data && data.items && data.items.length > 1) {
        setCurrentPage(1);
        setBookArray(data.items);
      }
    });
  };
  const changePage = (index: number) => {
    setCurrentPage(clamp(index, 1, bookArray.length - 1));
  };

  function clamp(num: number, min: number, max: number) {
    return num <= min ? min : num >= max ? max : num;
  }
  return (
    <section className="gradient-form bg-purple-100 p-1 h-[calc(100vh-4rem)]">
      <div className="flex justify-center text-gray-800  mt-1">
        <div className="bg-white shadow-lg rounded-lg mx-2 w-[calc(100vw-1rem)]  h-[calc(100vh-6rem)]">
          <h4 className="text-xl font-semibold mt-1 mb-4 pb-1 px-4 py-2 text-center  ">
            <Accordion allowZeroExpanded preExpanded={[0]}>
              <AccordionItem key="0" uuid={0}>
                <AccordionItemHeading className="bg-indigo-200 text-white mb-2">
                  <AccordionItemButton>
                    <div className="flex justify-between items-center">
                      <FaChevronRight className="text-2xl" />
                      <div>From Google Books</div>
                      <div></div>
                    </div>
                  </AccordionItemButton>
                </AccordionItemHeading>
                <AccordionItemPanel className="overflow-scroll overflow-x-hidden text-base animate-fadeIn transition-all ease-in-out  duration-200 ">
                  <div className="flex gap-4 px-2">
                    <input
                      type="text"
                      className="w-full"
                      placeholder="Search for a book"
                      onChange={(val) => setSearchText(val.target.value)}
                    />
                    <button
                      className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                      onClick={() => void searchBook(searchText)}
                    >
                      search
                    </button>
                  </div>
                  <div className="flex flex-col justify-center gap-2">
                    <div className="overflow-scroll overflow-x-hidden text-base h-6">
                      {bookArray[currentPage - 1]?.volumeInfo.title}
                    </div>

                    <Image
                      objectFit={"contain"}
                      src={
                        bookArray[currentPage - 1]?.volumeInfo.imageLinks
                          .thumbnail as string
                      }
                      width={150}
                      height={200}
                      alt="The cover of a book"
                    />
                    <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-2">
                      Choose
                    </button>
                    <div className="flex gap-8 justify-center items-center mb-4">
                      {currentPage > 1 ? (
                        <FaAngleLeft
                          className="text-lavender text-2xl"
                          onClick={() => {
                            changePage(currentPage - 1);
                          }}
                        />
                      ) : (
                        <FaAngleLeft className="text-gray-200 text-2xl" />
                      )}
                      {currentPage}
                      {currentPage < bookArray.length - 1 ? (
                        <FaAngleRight
                          className="text-lavender text-2xl"
                          onClick={() => {
                            changePage(currentPage + 1);
                          }}
                        />
                      ) : (
                        <FaAngleRight className="text-gray-200 text-2xl" />
                      )}
                    </div>
                  </div>
                </AccordionItemPanel>
                <AccordionItem key={1}>
                  <AccordionItemHeading className=" underline-offset-1 	text-decoration-line: underline mb-2">
                    <AccordionItemButton>
                      Add/Edit Book Data
                    </AccordionItemButton>
                  </AccordionItemHeading>
                  <AccordionItemPanel className="overflow-scroll overflow-x-hidden max-h-[calc(100vh-26rem)] ">
                    <CreateBookPage />
                  </AccordionItemPanel>
                </AccordionItem>
              </AccordionItem>
            </Accordion>
          </h4>
        </div>
      </div>
    </section>
  );
}
export default Test;

function api<T>(url: string): Promise<T> {
  return fetch(url).then((response) => {
    if (!response.ok) {
      throw new Error(response.statusText);
    }
    return response.json() as Promise<T>;
  });
}

export interface BookSearch {
  kind: string;
  totalItems: number;
  items: Item[];
}

export interface Item {
  kind: string;
  id: string;
  etag: string;
  selfLink: string;
  volumeInfo: VolumeInfo;
  saleInfo: SaleInfo;
  accessInfo: AccessInfo;
  searchInfo?: SearchInfo;
}

export interface VolumeInfo {
  title: string;
  subtitle?: string;
  authors: string[];
  publisher?: string;
  publishedDate: string;
  description?: string;
  industryIdentifiers: IndustryIdentifier[];
  readingModes: ReadingModes;
  pageCount: number;
  printType: string;
  categories?: string[];
  averageRating?: number;
  ratingsCount?: number;
  maturityRating: string;
  allowAnonLogging: boolean;
  contentVersion: string;
  panelizationSummary: PanelizationSummary;
  imageLinks: ImageLinks;
  language: string;
  previewLink: string;
  infoLink: string;
  canonicalVolumeLink: string;
}

export interface IndustryIdentifier {
  type: string;
  identifier: string;
}

export interface ReadingModes {
  text: boolean;
  image: boolean;
}

export interface PanelizationSummary {
  containsEpubBubbles: boolean;
  containsImageBubbles: boolean;
}

export interface ImageLinks {
  smallThumbnail: string;
  thumbnail: string;
}

export interface SaleInfo {
  country: string;
  saleability: string;
  isEbook: boolean;
  listPrice?: ListPrice;
  retailPrice?: RetailPrice;
  buyLink?: string;
  offers?: Offer[];
}

export interface ListPrice {
  amount: number;
  currencyCode: string;
}

export interface RetailPrice {
  amount: number;
  currencyCode: string;
}

export interface Offer {
  finskyOfferType: number;
  listPrice: ListPrice2;
  retailPrice: RetailPrice2;
}

export interface ListPrice2 {
  amountInMicros: number;
  currencyCode: string;
}

export interface RetailPrice2 {
  amountInMicros: number;
  currencyCode: string;
}

export interface AccessInfo {
  country: string;
  viewability: string;
  embeddable: boolean;
  publicDomain: boolean;
  textToSpeechPermission: string;
  epub: Epub;
  pdf: Pdf;
  webReaderLink: string;
  accessViewStatus: string;
  quoteSharingAllowed: boolean;
}

export interface Epub {
  isAvailable: boolean;
  acsTokenLink?: string;
  downloadLink?: string;
}

export interface Pdf {
  isAvailable: boolean;
  downloadLink?: string;
}

export interface SearchInfo {
  textSnippet: string;
}
